---
name: L'AURA
colors:
  surface: '#fbf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#fbf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f0'
  surface-container: '#efeeeb'
  surface-container-high: '#eae8e5'
  surface-container-highest: '#e4e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#55433f'
  inverse-surface: '#30312f'
  inverse-on-surface: '#f2f0ed'
  outline: '#87726e'
  outline-variant: '#dac1bc'
  surface-tint: '#964737'
  primary: '#6d281a'
  on-primary: '#ffffff'
  primary-container: '#8b3e2f'
  on-primary-container: '#ffbaac'
  inverse-primary: '#ffb4a5'
  secondary: '#516257'
  on-secondary: '#ffffff'
  secondary-container: '#d4e7d8'
  on-secondary-container: '#57685d'
  tertiary: '#573800'
  on-tertiary: '#ffffff'
  tertiary-container: '#764d00'
  on-tertiary-container: '#ffbf63'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad3'
  primary-fixed-dim: '#ffb4a5'
  on-primary-fixed: '#3e0501'
  on-primary-fixed-variant: '#783022'
  secondary-fixed: '#d4e7d8'
  secondary-fixed-dim: '#b8cbbd'
  on-secondary-fixed: '#0f1f16'
  on-secondary-fixed-variant: '#3a4b40'
  tertiary-fixed: '#ffddb3'
  tertiary-fixed-dim: '#fcba5a'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#633f00'
  background: '#fbf9f6'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2df'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '500'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: 0em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
  editorial-quote:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 32px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system expresses modern culinary luxury: tactile, sensory, and quietly confident. It balances high-end bistro intimacy with the clarity of a streamlined digital ordering and table reservation service.

### Design Movement
**Refined Contemporary Gastronomy & Warm Tactile Minimalism:**
- Unhurried, generous negative space evocative of linen-draped tables and architectural dining rooms.
- Subdued, warm translucent surfaces paired with fine hairline divisions.
- Editorial food presentation where photography serves as texture and warmth rather than standard e-commerce grid clutter.
- Tactile, muted transitions that convey physical craft, seasonal sourcing, and hospitality.

## Colors

The palette draws inspiration from organic raw ingredients, cast iron, clay pottery, and warm ambient bistro lighting.

- **Primary (`#8B3E2F` — Sienese Terracotta):** Used for primary calls-to-action, key accents, curated badges, and active state highlights. Evokes wood fire, aged ceramics, and reduction sauces.
- **Secondary (`#233329` — Deep Forest Olive):** Applied to high-contrast structural framing, primary headlines, premium navigation elements, and evening mode toggles. Grounds the warmth with culinary depth.
- **Tertiary (`#C98E32` — Warm Amber Gold):** Reserved for delicate status indicators, star ratings, chef's reserves, sommelier picks, and subtle metallic borders.
- **Neutral Canvas (`#FAF8F5` — Warm Alabaster Cream):** The foundational backdrop across light views, softening the clinical glare of white screens into fine-grain parchment.
- **Supporting Tones:**
  - Charcoal Surface (`#141715`) for contextual dark layers and cellar menus.
  - Border Hairline (`#E8E2D8`) for translucent, understated separation.
  - Soft Linen (`#F2ECE1`) for secondary card containers and recessed inputs.

## Typography

The type system creates deliberate tension between classical European menus and precise culinary technology.

- **Headlines (`Playfair Display`):** Carries natural rhythm, high editorial poise, and delicate serifs. Headings maintain a tight vertical lockup with slight negative letter tracking for larger sizes to avoid dispersion.
- **Body & Labels (`Plus Jakarta Sans`):** Provides rapid legibility for ingredient lists, allergen notices, tasting notes, and ordering checkout workflows.
- **Micro-labels and Accents:** Rendered in uppercase with generous tracking (`0.06em` to `0.08em`) to echo sommelier catalog numbering and Michelin guide annotations.

## Layout & Spacing

The layout is built on a responsive 12-column system (4 columns on mobile, 8 on tablet, 12 on desktop) centered within an intentional max-width canvas of `1320px`.

- **Desktop (`>= 1024px`):** Generous section padding (`margin: 3rem` to `4.5rem`) reinforces an unhurried, fine-dining tempo. Course progressions, curated tasting journeys, and multi-dish orders span alternating asymmetric grid spans (e.g., 5-col dish imagery vs. 7-col narrative breakdown).
- **Tablet (`768px - 1023px`):** Adapts to an 8-column grid with sticky side filters for wine and dietary pairing.
- **Mobile (`< 768px`):** Collapses to 4 columns with edge-to-edge photography cards, full-width thumb-accessible ordering ribbons, and safe-area anchored trays.
- **Vertical Spacing Rhythm:** Component spacing adheres strictly to 8pt increments (`space-sm` through `space-xl`) to establish seamless vertical cadences between course sections.

## Elevation & Depth

Visual depth combines warm frosted translucency with soft, warm-tinted ambient shadows, rejecting cold clinical drop shadows.

- **Level 0 (Flat / Canvas):** Plain cream backdrop (`#FAF8F5`) layered directly under typography and border dividers.
- **Level 1 (Menu Cards & Tasting Items):** Soft elevated panels using `#FFFFFF` with 70% opacity, bordered by hairline `rgba(139, 62, 47, 0.08)` and cast with an ambient shadow: `0 4px 20px -2px rgba(35, 51, 41, 0.04)`.
- **Level 2 (Active Selections & Flyout Trays):** Frosted glass panels layered with `backdrop-filter: blur(16px)`, background tint of `rgba(250, 248, 245, 0.85)`, bordered by `rgba(201, 142, 50, 0.25)`, and shadow: `0 12px 32px -4px rgba(35, 51, 41, 0.08)`.
- **Level 3 (Sommelier Modals & Reservation Overlays):** Deep focus overlays utilizing background `rgba(20, 23, 21, 0.45)` with interactive sheets surfaced at `#FAF8F5` and shadow: `0 24px 48px -12px rgba(20, 23, 21, 0.18)`.

## Shapes

The geometric personality of this design system is soft and disciplined. A subtle radius (`roundedness: 1` — 4px base, 8px for cards, 12px for modal overlays) maintains modern tailored precision without veering into playful or cartoonish pill shapes.

- **Action Elements & Inputs:** Fixed at 4px (`rounded-sm`), delivering an architectural, hand-pressed editorial print aesthetic.
- **Food & Beverage Cards:** Standardized at 8px (`rounded-lg`) to smoothly contain photography without cropping plating composition.
- **Status Pills & Vintage Tags:** Distinct exception with fully rounded borders (`rounded-full`) constrained only to petite metadata badges (e.g., "Grand Cru", "Wood-fired", "Vegan").

## Components

### Buttons
- **Primary (Terracotta Plate):** Background `#8B3E2F`, text `#FAF8F5`, subtle hover transition to `#733225`. Sharp 4px corners, letter-spaced label, min-height 48px.
- **Secondary (Forest Outline):** 1px border `#233329`, text `#233329`, transparent fill. Hover state transitions to soft tinted fill `rgba(35, 51, 41, 0.04)`.
- **Tertiary (Sommelier Minimal):** Text `#8B3E2F`, underline offset 6px with gold hover stroke `#C98E32`.

### Dish & Beverage Cards
- **Structure:** Vertical or horizontal split; photography framed in warm off-white border with 8px radius.
- **Details:** Playfair Display for dish title, Plus Jakarta Sans for origin notes and dietary markers, amber highlight for price.
- **Hover/Interaction:** Card lifts by 2px with an inner hairline highlight glow `rgba(201, 142, 50, 0.15)`.

### Chips & Dietary Filters
- Compact height (32px), bordered with `rgba(35, 51, 41, 0.12)`.
- Inactive state: Cream surface `#FAF8F5` with forest text `#233329`.
- Selected state: Deep Forest Olive `#233329` fill with crisp cream text `#FAF8F5` and subtle gold pip icon.

### Form Inputs & Reservation Fields
- Background: Soft Linen (`#F2ECE1`) or transparent with bottom hairline border.
- Inset padding: `12px 16px`.
- Active / Focus: Border changes to terracotta `#8B3E2F` with no harsh ring, replaced by a 2px soft warm glow (`rgba(139, 62, 47, 0.15)`).

### Badges & Ribbons
- **Chef's Recommendation:** Rich olive badge with gold typography (`#C98E32`), uppercase 10px tracking.
- **Pairing Suggestion:** Translucent pill badge with subtle glass blur and delicate serif icon.

### Floating Order Summary Bar
- Docked at the viewport bottom on mobile; frosted glass alabaster finish (`rgba(250, 248, 245, 0.92)`).
- Contains real-time course count, subtotal, and an expansive primary CTA for checkout.